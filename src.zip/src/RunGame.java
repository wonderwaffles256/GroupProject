public class RunGame {
    public static void main(String[] args) {

    }
}