public class ConsoleDriver {
    public static void main(String[] args) {
        //bulk of logic elsewhere
        //should only have input-output logic
        //such as: talk to user, get user input, show changes to user

        //eg
        //create am object of type Game, Adventure...
        //Game g = new Game();
        //maybe while(g.hasWon())
        //ask user for input
        //call g.displayStatus() --- or displayBoard()

        //can add a GUI with minimal if any changes to game logic
    }

    /**
     * Prints a menu to inform user and gather input
     */
    public void menu() {}
}
